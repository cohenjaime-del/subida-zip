import Link from 'next/link'
export default function AdminSidebar() {
  return (
    <aside className="w-64 bg-amitysGreen text-amitysWhite h-full py-8 px-4 flex flex-col gap-4">
      <Link href="/admin" className="font-bold text-lg">Dashboard</Link>
      <Link href="/admin/inventory">Inventory</Link>
      <Link href="/admin/clients">Clients</Link>
      <Link href="/admin/orders">Orders</Link>
      <Link href="/">Back to Shop</Link>
    </aside>
  )
}