type Props = {
  points: number
  nextReward: number
}
export default function LoyaltyTracker({ points, nextReward }: Props) {
  return (
    <div className="bg-amitysWhite border rounded p-4 mb-4 shadow">
      <h4 className="font-bold">Loyalty Points</h4>
      <div className="flex items-center gap-2">
        <span className="text-2xl font-bold">{points}</span>
        <span>points</span>
      </div>
      <div className="text-sm mt-2">
        {points >= nextReward
          ? "Congrats! You have a free product reward!"
          : `Buy ${nextReward - points} more products to unlock your next reward.`}
      </div>
    </div>
  )
}