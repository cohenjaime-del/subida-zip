import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useTranslations } from 'next-intl'
import Image from 'next/image'
import { motion } from 'framer-motion'

const LANGS = [
  { code: 'en', label: 'ENG' },
  { code: 'es', label: 'ESP' }
]

export default function Header() {
  const router = useRouter()
  const t = useTranslations('Header')
  return (
    <header className="flex items-center justify-between py-4 px-6 bg-amitysWhite shadow-md">
      <Link href="/">
        <span className="flex items-center gap-2">
          <Image src="/images/logo.png" alt="Amitys Logo" width={40} height={40} />
          <span className="font-bold text-amitysGreen text-xl">Amitys Professional</span>
        </span>
      </Link>
      <nav className="flex gap-6">
        <Link href="/shop" className="hover:underline">{t('shop')}</Link>
        <Link href="/about" className="hover:underline">{t('about')}</Link>
        <Link href="/blog" className="hover:underline">{t('blog')}</Link>
        <Link href="/contact" className="hover:underline">{t('contact')}</Link>
        <Link href="/loyalty" className="hover:underline">{t('loyalty')}</Link>
        <Link href="/cart" className="hover:underline">🛒</Link>
      </nav>
      <div className="flex gap-2">
        {LANGS.map(lang => (
          <button key={lang.code}
            className="text-sm px-2 py-1 border rounded hover:bg-amitysLightGreen"
            onClick={() => router.push(`/${lang.code}`)}
          >{lang.label}</button>
        ))}
        <Link href="https://instagram.com/amitysusa" target="_blank" rel="noopener noreferrer">
          <Image src="/images/instagram.svg" alt="Instagram" width={24} height={24} />
        </Link>
        <Link href="https://facebook.com/amitysusa" target="_blank" rel="noopener noreferrer">
          <Image src="/images/facebook.svg" alt="Facebook" width={24} height={24} />
        </Link>
        <Link href="https://tiktok.com/@amitysusa" target="_blank" rel="noopener noreferrer">
          <Image src="/images/tiktok.svg" alt="TikTok" width={24} height={24} />
        </Link>
      </div>
    </header>
  )
}