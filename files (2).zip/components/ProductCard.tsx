import Image from 'next/image'
import { motion } from 'framer-motion'
import Link from 'next/link'

type Product = {
  slug: string
  name: string
  price: number
  image: string
  description: string
  category: string
}

export default function ProductCard({ product }: { product: Product }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-amitysWhite rounded-lg shadow p-4 flex flex-col"
    >
      <Link href={`/products/${product.slug}`}>
        <Image
          src={product.image}
          alt={product.name}
          width={400}
          height={400}
          className="rounded mb-4"
          loading="lazy"
          quality={85}
        />
        <h3 className="text-lg font-bold mb-2">{product.name}</h3>
        <p className="text-amitysGreen font-semibold mb-2">${product.price}</p>
        <p className="text-sm">{product.description}</p>
      </Link>
    </motion.div>
  )
}