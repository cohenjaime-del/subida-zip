export default function Footer() {
  return (
    <footer className="bg-amitysWhite text-center py-6 border-t mt-12">
      <div>
        <span>© {new Date().getFullYear()} Amitys Professional. Cruelty-Free, All Natural. Since 2006.</span>
        <div className="mt-2 flex justify-center gap-4">
          <a href="https://instagram.com/amitysusa" target="_blank" rel="noopener noreferrer">Instagram</a>
          <a href="https://facebook.com/amitysusa" target="_blank" rel="noopener noreferrer">Facebook</a>
          <a href="https://tiktok.com/@amitysusa" target="_blank" rel="noopener noreferrer">TikTok</a>
        </div>
      </div>
    </footer>
  )
}