export default function CartPage() {
  // For demo, use static cart. In reality, fetch from Firebase/user context.
  const cart = [
    { name: "Super Pure Cleanser", price: 29, qty: 1 },
    { name: "Ilumine Hydrating Mask", price: 29, qty: 2 }
  ]
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0)
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Your Cart</h1>
      <div className="bg-amitysWhite rounded shadow p-6 max-w-lg mx-auto">
        {cart.map((item, idx) => (
          <div key={idx} className="flex justify-between mb-2">
            <span>{item.name} x{item.qty}</span>
            <span>${item.price * item.qty}</span>
          </div>
        ))}
        <hr className="my-4"/>
        <div className="flex justify-between font-bold text-lg">
          <span>Total</span>
          <span>${total}</span>
        </div>
        <a href="/checkout" className="bg-amitysGreen text-amitysWhite px-4 py-2 rounded font-bold mt-4 block text-center">Checkout</a>
      </div>
    </div>
  )
}