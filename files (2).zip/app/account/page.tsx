export default function AccountPage() {
  // In reality, fetch user info from Firebase Auth
  const user = { email: "admin@amitys.com", points: 210 }
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">My Account</h1>
      <div className="bg-amitysWhite rounded shadow p-6 max-w-lg mx-auto">
        <div className="mb-4">
          <strong>Email:</strong> {user.email}
        </div>
        <div className="mb-4">
          <strong>Loyalty Points:</strong> {user.points}
        </div>
        <a href="/orders" className="text-amitysGreen underline">View Orders</a>
      </div>
    </div>
  )
}