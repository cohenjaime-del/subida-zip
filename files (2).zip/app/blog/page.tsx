import Image from 'next/image'
export default function BlogPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Hair Tips & Trends</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-amitysWhite rounded shadow p-4">
          <Image src="/images/B1CYeA2IUAAiChQ.png" alt="Braided hairstyle" width={300} height={200} className="rounded"/>
          <h2 className="font-bold mt-2 mb-1">5 Tranças que você vai amar</h2>
          <p>Descubre las mejores trenzas para cada tipo de cabello. Aprende a crear estilos protectores y llenos de brillo con nuestros productos.</p>
        </div>
        <div className="bg-amitysWhite rounded shadow p-4">
          <h2 className="font-bold mb-1">Errores comunes con la chapinha</h2>
          <p>Cómo evitar daños al alisar tu cabello — tips para usar nuestra plancha inteligente y productos para proteger y recuperar la fibra capilar.</p>
        </div>
      </div>
    </div>
  )
}