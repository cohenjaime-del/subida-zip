import AdminSidebar from '@components/AdminSidebar'
export default function AdminDashboard() {
  return (
    <div className="flex">
      <AdminSidebar />
      <div className="flex-1 p-8">
        <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
        <ul>
          <li><a href="/admin/inventory" className="underline">Manage Inventory</a></li>
          <li><a href="/admin/clients" className="underline">View Clients</a></li>
          <li><a href="/admin/orders" className="underline">View Orders</a></li>
        </ul>
      </div>
    </div>
  )
}