export default function ClientsPage() {
  // In reality, fetch user profiles/orders from Firebase
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Clients</h1>
      <table className="w-full bg-amitysWhite rounded shadow">
        <thead>
          <tr>
            <th>Email</th>
            <th>Orders</th>
            <th>Loyalty Points</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>client@example.com</td>
            <td>3</td>
            <td>45</td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}