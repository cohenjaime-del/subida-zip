export default function InventoryPage() {
  // In reality, fetch from Firebase
  const products = [
    { name: "Super Pure Cleanser", stock: 23, price: 29 },
    { name: "Ilumine Hydrating Mask", stock: 11, price: 29 }
  ]
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Inventory</h1>
      <table className="w-full bg-amitysWhite rounded shadow">
        <thead>
          <tr>
            <th>Name</th>
            <th>Stock</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p, idx) => (
            <tr key={idx}>
              <td>{p.name}</td>
              <td>{p.stock}</td>
              <td>${p.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* Add/edit form would go here */}
    </div>
  )
}