export default function OrdersPage() {
  // In reality, fetch orders from Firebase
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Orders</h1>
      <table className="w-full bg-amitysWhite rounded shadow">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Client</th>
            <th>Total</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>ORD123</td>
            <td>client@example.com</td>
            <td>$87</td>
            <td>Shipped</td>
            <td>2025-08-01</td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}