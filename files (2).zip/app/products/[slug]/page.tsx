import { db } from '@lib/firebase'
import { doc, getDoc } from 'firebase/firestore'
import Image from 'next/image'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'

export default function ProductDetailPage({ params }) {
  const { slug } = params
  const [product, setProduct] = useState(null)
  useEffect(() => {
    async function fetchProduct() {
      const docRef = doc(db, 'products', slug)
      const docSnap = await getDoc(docRef)
      setProduct(docSnap.exists() ? docSnap.data() : null)
    }
    fetchProduct()
  }, [slug])
  if (!product) return <div>Loading...</div>
  return (
    <div className="container mx-auto py-8">
      <div className="flex flex-col md:flex-row gap-8">
        <Image src={product.image} alt={product.name} width={400} height={400} className="rounded"/>
        <div>
          <h1 className="text-2xl font-bold">{product.name}</h1>
          <p className="mb-2 text-amitysGreen font-bold">${product.price}</p>
          <p>{product.description}</p>
          <div className="mt-4">
            <button className="bg-amitysGreen text-amitysWhite px-4 py-2 rounded font-bold">Add to Cart</button>
          </div>
          <div className="mt-6">
            <h2 className="font-bold mb-2">Ingredients</h2>
            <ul className="list-disc ml-5">{product.ingredients.map((ing, idx) => <li key={idx}>{ing}</li>)}</ul>
            <h2 className="font-bold mt-4 mb-2">Benefits</h2>
            <ul className="list-disc ml-5">{product.benefits.map((ben, idx) => <li key={idx}>{ben}</li>)}</ul>
            <h2 className="font-bold mt-4 mb-2">Reviews</h2>
            <div>{product.reviews.map((rev, idx) => (
              <div key={idx} className="border-b py-2">{rev}</div>
            ))}</div>
          </div>
        </div>
      </div>
    </div>
  )
}