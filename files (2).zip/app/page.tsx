import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'

export default function HomePage() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.7 }}
      className="container mx-auto py-12"
    >
      <section className="flex flex-col md:flex-row gap-10">
        <div className="flex-1 flex flex-col justify-center">
          <h1 className="text-4xl font-bold text-amitysGreen mb-4">
            Natural Products For Best Results
          </h1>
          <p className="mb-6 text-lg">
            <strong>Formaldehyde Free, made with sustainably extracted ingredients like mango and avocado oil, essential to your capillary health and strength.</strong>
            <br />
            100% libre de formol, cabello liso 100% sin frizz.
          </p>
          <ul className="list-disc ml-5 text-md mb-4">
            <li>Cruelty free, All Natural and Formaldehyde free products for your health and well being.</li>
            <li>NEVER tested on animals.</li>
            <li>All ingredients sustainably sourced from Brazil.</li>
            <li>Devuelven el brillo, la suavidad y el equilibrio al cabello.</li>
          </ul>
          <Link href="/shop" className="bg-amitysGreen text-amitysWhite px-6 py-2 rounded font-bold shadow hover:bg-amitysLightGreen transition">Shop Now</Link>
        </div>
        <div className="flex-1 flex justify-center items-center">
          <Image
            src="/images/BvlcbZLIEAEkHNr.jpg"
            alt="Model with shiny hair"
            width={500}
            height={500}
            priority
            className="rounded-xl shadow-lg"
          />
        </div>
      </section>
      <section className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
        <motion.div whileHover={{ scale: 1.05 }} className="bg-amitysWhite p-6 rounded shadow">
          <h2 className="font-bold text-lg mb-2">Why Shop with Amitys?</h2>
          <ul className="list-disc ml-5">
            <li>Free shipping over $250</li>
            <li>30-day exchanges & returns</li>
            <li>24/7 support</li>
            <li>Flexible payments</li>
          </ul>
        </motion.div>
        <motion.div whileHover={{ scale: 1.05 }} className="bg-amitysWhite p-6 rounded shadow">
          <h2 className="font-bold text-lg mb-2">Brazilian Ingredients</h2>
          <ul className="list-disc ml-5">
            <li>Mango, avocado oil, argan, babacu, karité, coconut oil, honey extract</li>
            <li>Sourced sustainably since 2006</li>
            <li>Adapted for all hair types</li>
          </ul>
        </motion.div>
        <motion.div whileHover={{ scale: 1.05 }} className="bg-amitysWhite p-6 rounded shadow">
          <h2 className="font-bold text-lg mb-2">Professional Results</h2>
          <ul className="list-disc ml-5">
            <li>Alisado Orgánico Brasileño (organic straightening, no formol)</li>
            <li>Reduces frizz, adds shine, volume control</li>
            <li>Results last up to 6 months</li>
          </ul>
        </motion.div>
      </section>
      <section className="mt-12 text-center">
        <h2 className="text-2xl font-bold mb-2">Before & After</h2>
        <Image src="/images/B0KEuOxIMAEjikR.jpg" alt="Luminous Silver Kit Promo" width={600} height={300} className="mx-auto rounded-lg shadow"/>
      </section>
    </motion.div>
  )
}