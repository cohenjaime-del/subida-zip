export default function ContactPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Contact Us</h1>
      <form className="bg-amitysWhite rounded shadow p-6 max-w-lg mx-auto">
        <label className="block mb-2 font-bold">Name</label>
        <input className="w-full border rounded p-2 mb-4" type="text" name="name" required />
        <label className="block mb-2 font-bold">Email</label>
        <input className="w-full border rounded p-2 mb-4" type="email" name="email" required />
        <label className="block mb-2 font-bold">Message</label>
        <textarea className="w-full border rounded p-2 mb-4" name="message" required rows={5}></textarea>
        <button type="submit" className="bg-amitysGreen text-amitysWhite px-4 py-2 rounded font-bold">Send</button>
      </form>
    </div>
  )
}