import Image from 'next/image'

export default function AboutPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">About Amitys Professional</h1>
      <div className="flex flex-col md:flex-row gap-8">
        <div className="flex-1">
          <p>
            <strong>Founded in Brazil in 2006, Amitys Professional is committed to cruelty-free, all-natural hair care with sustainable ingredients.</strong>
            <br />
            Our factory has produced premium treatments for 20+ years, blending tradition and cutting-edge nanotechnology. We never use formaldehyde, parabens, or sulfates. Our products restore shine, strength, and balance to all hair types, whether curly, straight, dry, or chemically treated.
            <br />
            <br />
            <strong>All our ingredients are sustainably sourced from Brazil, including mango, avocado oil, babacu, karité, argan, coconut, and honey extract.</strong>
          </p>
        </div>
        <div className="flex-1 flex flex-col gap-4">
          <Image src="/images/B0JqleHIIAAGHhu.jpg" alt="Multi-device site" width={400} height={300} className="rounded shadow"/>
          <Image src="/images/B-Ts7lHCIAANFoS.jpg" alt="Control Plus Kit" width={400} height={300} className="rounded shadow"/>
        </div>
      </div>
    </div>
  )
}