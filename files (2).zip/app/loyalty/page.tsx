import LoyaltyTracker from '@components/LoyaltyTracker'
export default function LoyaltyPage() {
  // Fetch user's points from Firebase or context
  const points = 180
  const nextReward = 200
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Your Loyalty Rewards</h1>
      <LoyaltyTracker points={points} nextReward={nextReward} />
      <p>
        Accumulate 1 point for each $1 spent. Redeem points for discounts or buy 3 products, get the 4th free (auto-applied to cart).
        Track your progress and unlock exclusive rewards!
      </p>
    </div>
  )
}