// Netlify Function handler: send WhatsApp message via Twilio
import { Handler } from '@netlify/functions'
import twilio from 'twilio'

const accountSid = process.env.TWILIO_ACCOUNT_SID
const authToken = process.env.TWILIO_AUTH_TOKEN
const whatsappNumber = process.env.WHATSAPP_NUMBER

const client = twilio(accountSid, authToken)

const handler: Handler = async (event) => {
  const { message } = JSON.parse(event.body || '{}')
  try {
    const response = await client.messages.create({
      from: 'whatsapp:+14155238886', // Twilio sandbox
      to: `whatsapp:${whatsappNumber}`,
      body: message
    })
    return { statusCode: 200, body: JSON.stringify({ success: true, sid: response.sid }) }
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) }
  }
}

export { handler }