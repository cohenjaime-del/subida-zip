// Netlify Function handler: process Stripe payment, store order in Firebase, send WhatsApp notif
import { Handler } from '@netlify/functions'
import Stripe from 'stripe'
import admin from 'firebase-admin'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2022-11-15' })
const whatsappNumber = process.env.WHATSAPP_NUMBER

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.applicationDefault(),
    databaseURL: process.env.FIREBASE_DB_URL
  })
}
const db = admin.firestore()

const handler: Handler = async (event) => {
  const { items, currency, user } = JSON.parse(event.body || '{}')
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: items.map(item => ({
        price_data: {
          currency,
          product_data: { name: item.name },
          unit_amount: item.price * 100,
        },
        quantity: item.qty,
      })),
      mode: 'payment',
      customer_email: user.email,
      success_url: 'https://amitys.com/success',
      cancel_url: 'https://amitys.com/cancel',
    })
    // Store order in Firebase
    await db.collection('orders').add({ user, items, currency, stripeSession: session.id })
    // Send WhatsApp notification (reuse sendWhatsApp.ts logic)
    // ...
    return { statusCode: 200, body: JSON.stringify({ success: true, sessionId: session.id }) }
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) }
  }
}
export { handler }